package example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com"); //open browser
		
		String title = driver.getTitle();
		System.out.println(title);
		
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		//sendkeys : enter data 
				driver.findElement(By.name("q")).sendKeys("selenium");
				
				//mouse click 
				driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		
		
		
		

	}

}
