package example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.facebook.com"); 
		
		driver.findElement(By.name("firstname")).sendKeys("anubha");
		driver.findElement(By.name("lastname")).sendKeys("bhat");
		Thread.sleep(5000);
		driver.findElement(By.name("reg_email__")).sendKeys("ravi123edu@gmail.com");
		driver.findElement(By.name("reg_email_confirmation__")).sendKeys("ravi123edu@gmail.com");
		driver.findElement(By.name("reg_passwd__")).sendKeys("abc123");
		driver.findElement(By.name("birthday_day")).sendKeys("12");
		driver.findElement(By.name("birthday_month")).sendKeys("december");
		driver.findElement(By.name("birthday_year")).sendKeys("1990");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"u_0_9\"]")).click();
		driver.findElement(By.name("websubmit")).click();
		//driver.findElement(By.name("sex")).sendKeys(Keys.ENTER);
     }
	

}
