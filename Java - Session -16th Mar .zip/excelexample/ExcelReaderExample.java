package excelexample;

import java.io.BufferedReader;
import java.io.FileInputStream;//file 
import java.io.InputStreamReader; //console , buffer   

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


//SCanner : char by cha r
public class ExcelReaderExample {

	public static void main(String[] args) {
	
		try
		{
			
			FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\Documents\\Sandbox\\Excel\\Sample - Superstore.xls");
			HSSFWorkbook book =new  HSSFWorkbook(fs);
			
			//HSSFSheet sheet = book.getSheetAt(1); //by index
			HSSFSheet sheet = book.getSheet("Orders"); //by name
			
			
			int sheetcount = book.getNumberOfSheets();
			System.out.println("sheet count : "+sheetcount);
			
			int rowcount = sheet.getPhysicalNumberOfRows();
			System.out.println("row count : "+rowcount);
			
			int colcount = sheet.getRow(0).getPhysicalNumberOfCells();			
			System.out.println("col count :"+colcount);
			
			//HSSFRow row  = sheet.getRow(5);
			//HSSFCell cell = row.getCell(0);
			//System.out.println(cell.getStringCellValue());
			
			
			//read data from given sheet 
			for(int i=1;i<rowcount;i++)
			{
				
				HSSFRow row  = sheet.getRow(i);
				
				//HSSFCell cell = row.getCell(0);
				//System.out.print(cell.getNumericCellValue());
								
				//cell = row.getCell(1);
				//System.out.print(cell.getStringCellValue());
				
				
				//System.out.println(	cell.getCellType());
				
				for(int c =0; c<5;c++)
				{
					HSSFCell cell = row.getCell(c);
					
					try {
						System.out.print(cell.getStringCellValue());
						
					}
					catch (Exception e) {
					
						try {
						
							System.out.print(cell.getNumericCellValue());
						}
						catch (Exception e1) {
							
						
							try {
								System.out.print(cell.getDateCellValue());
							}
							catch (Exception e2) {
								
								
							}
							
							
						}
						
						
						
					}
					
					
					
					
				}
				
				System.out.println();
			}
			
			System.out.println("end");
			
			//input
			/*
			BufferedReader br = 
					new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter data :");
			String ss = br.readLine();			
			*/
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}

	}

}
