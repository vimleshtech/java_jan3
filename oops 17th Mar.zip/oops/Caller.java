package oops;

public class Caller {

	public static void main(String[] args) {

		//here e is an object of Employee class 
		Employee e = new Employee();
		//e.newemployee();
		//e.compute();
		//e.getemployee();
		
	
		/*
		Employee e1 = new Employee("india");
		Employee e2 = new Employee("us");
		
		
		Employee e3 = new Employee("us",1);
		
		Employee e4 =new Employee(e3);
		e4.getemployee();
		*/
		
		Employee e1[] =new Employee[4];
		for(int i=0; i<4;i++)
		{
			e1[i] = new Employee();
			e1[i].newemployee();
			e1[i].compute();
			
		}
		
		for(int i=0; i<4;i++)
		{
			e1[i].getemployee();
		}
		
	}

}
