package oops;
import java.util.Scanner;

public class question {
	
	public void emp()
	{
		String name;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter emp name");
		name=sc.next();
		
		sc.close();
	}
	
	question(String name)
	{
		String a[]= new String[10];
	}
	void display()
	{
		//System.out.println(a);
	}
	public static void main (String[] ar)
	{
		
	}
}
