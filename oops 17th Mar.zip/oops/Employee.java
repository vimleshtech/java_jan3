package oops;

import java.util.Scanner;

public class Employee {

	//data member
	private int eid;
	private  String name;
	private int basic;
	private double hra;
	private double da;
	private double msal;
	private double ysal;
	private double tax;
	
	public Employee()
	{
		System.out.println("Object is created.");
	}
	
	public Employee(String country)
	{
		if(country.equals("india"))
		{
			System.out.println("Guest User");
			name = "Guest User";
			
		}
		else if(country.equals("us"))
		{
			System.out.println("New User");
			name = "New USer";
		}
		else 
		{
			System.out.println("Other USer");
			name ="Other User";
		}
	}

	public Employee(String country,int id)
	{
		
	}
	//copy constructor 
	public Employee(Employee e)
	{
		name = e.name;
		
	}
	//methods
	public void newemployee() 
	{
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter eid : ");
		eid  = sc.nextInt();
		
		System.out.println("enter name: ");
		name  = sc.next();
		
		System.out.println("enter salary : ");
		basic= sc.nextInt();
		
		
	}
	
	public  void compute()
	{
		hra = basic *.50;
		da = basic *.20;
		msal = basic+hra+da;
		ysal = msal*12;
		
		
		if(ysal<500000)
		{
			tax = 0;	
		}
		else if(ysal<1000000)
		{
			tax = 12500+  (ysal-500000)*.20;
		}
		else
		{
			tax = 112500+  (ysal-1000000)*.30;
		}
	}
	public void getemployee()
	{
		
		System.out.println("eid : "+eid);
		System.out.println("name : "+name);
		System.out.println("msal : "+msal);
		System.out.println("ysal : "+ysal);
		System.out.println("tax : "+tax);
	}
}
