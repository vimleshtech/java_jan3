package example;

import static org.testng.Assert.assertEqualsDeep;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CollectionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ArrayList al = new ArrayList();
		al.add("nitin");
		al.add("java is programing language");
		
		
		System.out.println(al.size()); 
		System.out.println(al.get(1)); //2nd element
		
		al.remove(1); //2nd element
		System.out.println(al.get(1));
		
		//read all data one by one
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		
		//List : is interface 
		List l = new ArrayList();
		l.add(11);
		l.add("nitin");
		
		System.out.println(l.size());
		System.out.println(l.get(0));
		
		
		//HaspMap
		HashMap map  = new HashMap();
		map.put("a","alpha"); //a is key and alpha is data
		map.put("t","tata");
		map.put("d","delta");
		map.put("1",100);
		
		System.out.println(map.size());
		System.out.println(	map.get("1"));
	
		
		
		//template 
		ArrayList<String> data = new ArrayList<>();
		
		data.add("nitin");
		data.add("divya");
		
		//data.add(1);//we cannot add
		
		/* 
		 * test.txt
		 * this is java code.
		 * java is programing language 
		 * 
		 * wap to get word count
		 * 
		 * 
		 */
		
		
	}

}
