package example;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;




public class Collection1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileReader fr=new FileReader("C:\\Users\\vkumar15\\Desktop\\test.txt");
		
		//FileWriter fw= new FileWriter("this is java code");
		BufferedReader br=new BufferedReader(fr);
		//BufferedWriter br=new BufferedWriter(fw);
		int wordcount=0;
		
		String data ="";
		ArrayList al = new ArrayList();
		while( (data= br.readLine() )!=null) {
			
			al.add(data);
		}
		
		for(int i=0; i<al.size();i++)
		{
			
			String dd[] =al.get(i).toString().split(" ");
			
			wordcount  +=dd.length;
			//System.out.println(al.get(i));
		
		}
		
		System.out.println(wordcount);

	}

}
