package examplwe;

import java.util.Scanner;

public class ConsoleInputOutput {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		int a;
		String name;
		
		System.out.println("enter id : ");
		a = s.nextInt();
				
		System.out.println("enter name :");
		name = s.next();
		
		System.out.println("id is "+a+" and name is "+name);
				

	}

}
