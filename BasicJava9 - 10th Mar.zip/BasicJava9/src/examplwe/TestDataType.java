package examplwe;

import javax.sound.midi.Soundbank;

public class TestDataType {

	public static void main(String[] args) {

		int a=11;
		System.out.println(a);
		
		long l =44444;
		System.out.println(l);
		
		l = a; //implicit type casting 
		System.out.println(l);
		
		//explict type casting 
		a =(int) l; //we cannot convert long to int		
		System.out.println(a);
		
		//
		String s ="skhs hgsfhfh fgssgd gf437536345345###";
		char c = '%';
		char cc[] = {'%','a','1','2'};
		
		
		//
		float bcd =43333;
		System.out.println(bcd);
		bcd =43333.2f;
		System.out.println(bcd);

		//
		double out = 100 *1.18f; //100*18/100 = 18
		System.out.println(out);
		
		
		
		
	}

}
