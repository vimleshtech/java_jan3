package examplwe;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileInputOutputExample {

	public static void main(String[] args) throws IOException {
	
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\Tax\\out.txt",true);
		//true : append
		//false : overwrite 
		
		BufferedWriter bw =new BufferedWriter(fw);
		
		bw.write("Hi, 1 This is my first file which is created from java code");
		bw.newLine();
		bw.write("bye");
		bw.newLine();
		
		bw.close();  // clear the buffer
		fw.close(); //save the file

	}

}
