package dbconnection;
import java.sql.Connection;		//establish the connection from code to db
import java.sql.DriverManager;	//load or register the driver (type of db server) 

import java.sql.PreparedStatement;  //run sql statement/command
import java.sql.ResultSet;  //store the sql result or output
import java.sql.SQLException;
import java.sql.Statement;

public class example {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

			Class.forName("com.mysql.jdbc.Driver");
			//"jdbc:mysql://server/db","user","pwd"
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/rds_learning", "root","root");
			
			//read
			Statement st =con.createStatement();
			//select
			ResultSet rs = 	st.executeQuery("select * from users");
			
			
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"\t"+rs.getString(2));
			}
			
			//write 
			st =con.createStatement();
			//insert, update, delete 
			st.executeUpdate("insert into users(uid,name,email,pwd) values(3,'raman','raman@gmail.co','abcd');");
			st.executeUpdate("insert into users(uid,name,email,pwd) values(4,'raj','ram@gmail.com','abc');");
			st.executeUpdate("insert into users(uid,name,email,pwd) values(5,'ram','raj@gmail.com','abcde');");
			st.executeUpdate("update users set name ='anu' where uid =3");
			
			
		}

	

	}


