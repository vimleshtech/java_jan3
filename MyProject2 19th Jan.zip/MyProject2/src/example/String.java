package example;

public class String {

}
