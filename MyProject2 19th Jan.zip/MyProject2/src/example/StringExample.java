package example;

public class StringExample {

	public static void main(String[] args) {
		
		String s ="this is JAVA code  ";
		
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		
		System.out.println(s.length());		
		System.out.println(s.replace("i", "xy"));
		
		System.out.println(s.substring(1, 4));
		
		System.out.println(s.trim());
		
		System.out.println(s.indexOf("is"));
		
		System.out.println(s.charAt(2));
		
		//
		String d[] = s.split(" ");
		System.out.println(d[0]);
		System.out.println(d[1]);
		
		//
		s = s.concat("yz");
		System.out.println(s);

		//
		if(s.equalsIgnoreCase("this is java code "))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		///
		if(s.equalsIgnoreCase("this is JAVA code  yz"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(s.contains("JAVA"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		//
		if(s.startsWith("th"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		//
		if(s.endsWith("th"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
	}

}
