package example;

public class string1 {

	public static void main(String[] args) {
		
		
		String s = " This is testing class ";
		System.out.println(s.length());	
	}
	
	
	}


