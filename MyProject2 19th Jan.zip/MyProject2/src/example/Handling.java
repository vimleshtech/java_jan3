package example;

public class Handling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="My name is John ";
		System.out.println(s.length());
				
	}

}
