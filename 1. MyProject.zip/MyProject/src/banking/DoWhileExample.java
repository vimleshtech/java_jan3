package banking;

public class DoWhileExample {

	public static void main(String[] args) {
	
		int i=0;
		do
		{
			
			System.out.println(i);
			i++;
		}while(i<0); 

	}

}
