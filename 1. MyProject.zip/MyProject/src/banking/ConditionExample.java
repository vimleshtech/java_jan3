package banking;

public class ConditionExample {

	public static void main(String[] args) {

		int n=11;
		
		//if condition 
		if(n%2==0) 
		{
			System.out.println("even");
		}
		
		//if else condition 
		if(n%2==0)
		{
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}
		
		
		//if else if else if .... else /ladder if else
		int a,b,c;
		a =33;
		b =44;
		c =4;
		
		if(a>b && a>c)
		{
			System.out.println("a is gt");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is gt");
		}
		else
		{
			System.out.println("c is gt");
		}
		
		//nested if else / if inside if
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("a is gt");
			}
			else
			{
				System.out.println("c is gt");
			}
		}
		else
		{
			if(b>c)
				System.out.println("b is gt");
			else
				System.out.println("c is gt");
			
		}
		
		

	}

}
