package banking;

import java.util.ArrayList;

public class Calculater 
{

	public static void main(String[] ab) 
	{	
		int a,b,c; //declare variable		
		a =1;
		b =434;		
		c=a+b;
		
		System.out.println(c);
		
		//data type
		byte bb=1;
		short ss=1333;
		int i =322322233;
		long l =3333333333333333228l;
		
		System.out.println(l);
				
		float data=3333.2f;
		System.out.println(data);
		
		double d1 =32333333333.3333333;
				
		char cc ='s';
		char cccc ='1';
		System.out.println(cc);
		
		boolean bo = true;
				
		String name ="raman sinha skhsjhhgshsghgsgs";
		System.out.println(name);
				
		int ii,jj;
		ii=0;
		jj=0;		
		
		System.out.println(ii++);//0
		System.out.println(++jj);//1
		
		System.out.println(ii);//1
		System.out.println(jj);//1
	}

}
