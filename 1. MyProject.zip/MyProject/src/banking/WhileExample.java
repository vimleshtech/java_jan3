package banking;

public class WhileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=0; //init /start from 
		while(i<10) //condition /limit
		{
			
			i++;//increment/step
			System.out.println(i);
		}
	}

}
