package banking;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		int d[]= {111,22,333,444,3233};
		int e[]= {100,20,11,34,78};
		int f[]= new int[5];
		//System.out.println(d);
		//System.out.println(d[0]);
		for(i=0;i<5;i++)
		{
			f[i]=d[i]-e[i];
		}
			//advance loop
		
			for(int a: f)
			System.out.println(a);
		
		 
	}

}
