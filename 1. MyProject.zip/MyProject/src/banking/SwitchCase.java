package banking;

public class SwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int day=7;
		int a=22,b=22;
		switch (day)
		{
			case 1:
				System.out.println(a+b);
				break;
			case 2:
				System.out.println(a-b);
				break;
			case 3:
				System.out.println(a*b);
				break;
			default:
				System.out.println("out of option");
				break;
		}
	}

}
