package stringexample;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class StringFunctionExample {
	
	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		String str,nstr;
		
		System.out.println("enter string : ");
		str =sc.nextLine();
		
		int l = str.length();
		System.out.println(l);
		
		char c = str.charAt(2);
		System.out.println(c);
		
		//conver to ascii code
		int a = c;
		System.out.println("ascii :" +a);
		
		
		nstr = str.toUpperCase();
		System.out.println(nstr);
	
		nstr = str.toLowerCase();
		System.out.println(nstr);
		
		nstr = str.replace("a", "xy");
		System.out.println(nstr);
		
		int ps = str.indexOf("m");
		System.out.println(ps);
		
		nstr = str.trim();
		System.out.println(nstr);
		
		nstr = str.substring(2, 5);//from 2 to <5
		System.out.println(nstr);
		
		//
		String nn[] = str.split(" ");
		System.out.println(nn[0]);
		System.out.println(nn[1]);
		
		//
		if(str.equals("abc"))
		{
			System.out.println("match ");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(str.equalsIgnoreCase("abc"))
		{
			System.out.println("match ");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(str.startsWith("abc"))
		{
			System.out.println("match ");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(str.endsWith("abc"))
		{
			System.out.println("match ");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(str.contains("abc"))
		{
			System.out.println("match ");
		}
		else
		{
			System.out.println("not match");
		}
		
		
		
	}
	

}
