package oops2;


class a {
	
	
	int x =1;
}

public class Compute extends a {

	private int n;
		
	int x=2;
	static int y;
	
	Compute()
	{
		n =0;
	}
	
	Compute(Compute o )
	{
		this.n = o.n;
		
	}
	
	public void getKey() {
		
		this.n +=12;
		System.out.println(this.n);
	}
	
	
	static void test()
	{
		System.out.println("test static function ");
	}
	void test2(int x)
	{
		System.out.println(x);//local 
		System.out.println(this.x);//class level (if not exit then super)
		System.out.println(super.x);
	}
}
