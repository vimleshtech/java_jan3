package oops2;

public class Caller {

	
	static void add(int a, int b)
	{
		System.out.println(a+b);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		add(1,2);
		
		
		Compute c =new Compute();
		c.getKey();
		
		c.x =1;
		c.y =1;
		
		
		Compute c1 =new Compute(c);
		c1.getKey();
		
		c1.x =10;
		c1.y =10;
		
		System.out.println(c.x); //1
		System.out.println(c1.x); //10
		
		System.out.println(c.y); //10   1
		System.out.println(c1.y);//10
		
		
		
		Compute.test();
		//Compute.getKey();//cannot be access
		//Compute.x =11; //cannot be access
		Compute.y =1;
		

		Compute cc =new Compute();
		cc.test2(10);
		
		String st ="  this is java code  ";
		
		int l =st.length();
		System.out.println(l);

		String s = st.replace("a","xy");
		System.out.println(s);
		
		l = st.indexOf("v");
		System.out.println(l);
		
		
		char co = st.charAt(l);
		System.out.println(co);
		
		st = st.toUpperCase();
		System.out.println(st);
		
		st = st.toLowerCase();
		System.out.println(st);
		
		st = st.trim();
		System.out.println(st);
		
		s = st.substring(2, 6);
		System.out.println(s);
		
		
		char arr[] = st.toCharArray(); //{'t','h''is'..}
		for(char ar: arr) {
			System.out.println(ar);
		}
		
	
		
		String ss[] = st.split(" ");
		for(String ar: ss) {
			System.out.println(ar);
		}
		
		
		s = st.concat("test");
		System.out.println(s);
		

		if(st.equals("test"))
		{
			System.out.println("match");
		}
		

		if(st.startsWith("test"))
		{
			System.out.println("match");
		}

		if(st.endsWith("test"))
		{
			System.out.println("match");
		}
		

		if(st.contains("test"))
		{
			System.out.println("match");
		}
		

		if(st.equalsIgnoreCase("test"))
		{
			System.out.println("match");
		}
		
		///
		String s1,s2;
		
		s1 ="a";
		s2="a";
		
		if(s1==s2)
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}

		s1 = s1+"b";		
		s2 = s2+"b";
		

		if(s1==s2)
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}


		if(s1.equals(s2))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}

		
		
		
		StringBuffer sb = new StringBuffer();
		sb.append("ss");
		
		
	}

}
