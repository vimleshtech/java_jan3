package oops2;

public class Compute2 {

	int x=1;
	static int z;
	
	final int y =1;
			
	void test()
	{
		x =11;
		//y =22;//cannot
		
		x =1;
		z=1;
		
	}
	static void test2()
	{
		Compute2 o =new Compute2();
		o.x =1;
		z=1;
				
	}
}
