package oops2;

public class Test {

	int a =10;
			
}
