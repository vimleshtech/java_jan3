package example;

public class Average_marks {

	public static void main(String[] args) {
		
		int rollno,a,b,c,d,e;
		String name;
		int average;
		rollno= 001;
		name = "Chetan";
		a=80;
		b=70;
		c=85;
		d=95;
		e=100;
		average= (a+b+c+d+e)/5;
		
		System.out.println("Average of 5 no. is: " + average);
		System.out.println("name of the student: "+ name);
		System.out.println("Roll no. of a Student: "+rollno);
		
		
		
				
		
		

	}

}
