package example;

import java.util.*;

public class InputAndOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);		
		int n;
		
		System.out.println("enter data : ");
		n = sc.nextInt(); //take input
		
		System.out.println(n);
		
	}

}
